package Sendit;

public class Main
{
    public static void main(String args[])
    {
        SenditGui g = new SenditGui();
        g.homegGui();


    }
}
